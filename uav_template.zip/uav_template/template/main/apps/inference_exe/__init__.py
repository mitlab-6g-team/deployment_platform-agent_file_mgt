default_app_config = 'main.apps.inference_exe.apps.InferenceExeConfig'
